// src/api/index.ts
// The ONLY file components should import data functions from.
// Right now every function calls the in-memory mock after a small fake delay.
// To go live, replace each body with a fetch() call that returns the same type, e.g.
//
//   export async function getMeals(date: string): Promise<Meal[]> {
//     const res = await fetch(`/api/meals?date=${date}`);
//     if (!res.ok) throw new ApiError('BAD_REQUEST', await res.text());
//     return res.json();
//   }

import * as db from './mock';
import { http } from './http';
import * as paymentsDb from './payments';
import type {
  AdminOverview,
  BillingItem,
  CreateLeaveInput,
  ForecastPoint,
  LeaveRequest,
  Meal,
  MealType,
  Notification,
  Preferences,
  QrToken,
  RebateEntry,
  RedeemResult,
  Timing,
  TimingOverride,
  WasteStat,
} from './types';

export * from './types';
export type { Payment, PaymentMethod } from './payments';

/** A date on which one or more meals are closed (used by the admin Closures page). */
export interface Closure {
  /** 'YYYY-MM-DD' */
  date: string;
  /** The closed meals on that date, in breakfast, lunch, dinner order. */
  mealTypes: MealType[];
  /** true when all three meals are closed. */
  entireMess: boolean;
}

const FAKE_DELAY_MS = 250;

function delay(ms: number = FAKE_DELAY_MS): Promise<void> {
  const jitter = Math.random() * 120;
  return new Promise((resolve) => setTimeout(resolve, ms + jitter));
}

// ----------------------------------------------------------------- meals

export async function getMeals(date: string): Promise<Meal[]> {
  const rows = await http<Array<Pick<Meal, 'id' | 'type' | 'date' | 'status' | 'closed' | 'serviceStart' | 'serviceEnd' | 'cutoffAt'>>>(`/api/meals?date=${encodeURIComponent(date)}`);
  const samples = db.getMeals(date);
  return rows.map(row => {
    const sample = samples.find(x => x.type === row.type);
    if (!sample) throw new Error(`Missing display for ${row.type}`);
    return {
      ...sample,
      ...row,
      title: `Sample menu: ${sample.title}`,
      description: 'Illustrative menu only. Your mess has not published its real menu yet.',
      tags: ['sample menu'],
    };
  });
}

export async function setMealBooking(mealId: string, booked: boolean): Promise<Meal> {
  await http(`/api/meals/${encodeURIComponent(mealId)}/booking`, { method: 'PUT', body: { booked } });
  const date = mealId.split('_')[0];
  const meal = (await getMeals(date)).find(x => x.id === mealId);
  if (!meal) throw new Error('Meal was not returned after saving.');
  return meal;
}

// ----------------------------------------------------------------- leave

export async function createLeave(input: CreateLeaveInput): Promise<LeaveRequest> {
  return http<LeaveRequest>('/api/leaves', { method: 'POST', body: input });
}

export async function getLeaves(): Promise<LeaveRequest[]> {
  return http<LeaveRequest[]>('/api/leaves');
}

export async function cancelLeave(leaveId: string): Promise<LeaveRequest> {
  return http<LeaveRequest>(`/api/leaves/${encodeURIComponent(leaveId)}`, { method: 'DELETE' });
}

export async function updateLeave(leaveId: string, input: CreateLeaveInput): Promise<LeaveRequest> {
  return http<LeaveRequest>(`/api/leaves/${encodeURIComponent(leaveId)}`, { method: 'PUT', body: input });
}

// -------------------------------------------------------------------- QR

export async function getQrToken(mealId: string): Promise<QrToken> {
  return http<QrToken>(`/api/qr/${encodeURIComponent(mealId)}`, { method: 'POST' });
}

export async function redeem(tokenOrCode: string): Promise<RedeemResult> {
  const value = tokenOrCode.trim();
  return http<RedeemResult>('/api/staff/redeem', {
    method: 'POST',
    body: value.startsWith('KT1.') ? { token: value } : { manualCode: value },
  });
}

// -------------------------------------------------------- billing & rebates

/** month = 'YYYY-MM'; defaults to the current month. */
export async function getBilling(month?: string): Promise<BillingItem[]> {
  await delay();
  return db.getBilling(month);
}

/** Every entry is labelled "Demo policy" until the real rebate rules exist. */
export async function getRebates(): Promise<RebateEntry[]> {
  await delay();
  return db.getRebates();
}

/** Payments the student made in a month. month = 'YYYY-MM'; defaults to the current month. */
export async function getPayments(month?: string): Promise<paymentsDb.Payment[]> {
  await delay();
  const now = new Date();
  const key =
    month ?? `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  return paymentsDb.getPayments(key);
}

// ------------------------------------------------ preferences & notifications

export async function getPreferences(): Promise<Preferences> {
  return http<Preferences>('/api/student/preferences');
}

export async function savePreferences(preferences: Preferences): Promise<Preferences> {
  return http<Preferences>('/api/student/preferences', { method: 'PUT', body: preferences });
}

export async function getNotifications(): Promise<Notification[]> {
  return http<Notification[]>('/api/student/notifications');
}

export async function markNotificationRead(id: string): Promise<void> {
  await http(`/api/student/notifications/${encodeURIComponent(id)}/read`, { method: 'PATCH' });
}

export async function markAllNotificationsRead(): Promise<void> {
  await http('/api/student/notifications/read-all', { method: 'PATCH' });
}

// ------------------------------------------------------- admin analytics

export async function getForecast(mealType: MealType = 'lunch'): Promise<ForecastPoint[]> {
  await delay();
  return db.getForecast(mealType);
}

export async function getWasteStats(days: number = 7): Promise<WasteStat[]> {
  await delay();
  return db.getWasteStats(days);
}

export async function getAdminOverview(): Promise<AdminOverview> {
  await delay();
  return db.getAdminOverview();
}

// ------------------------------------------------- timings & closures

/** Effective timings for a date (defaults to today). */
export async function getTimings(date?: string): Promise<Timing[]> {
  return http<Timing[]>(`/api/admin/timings${date ? `?date=${encodeURIComponent(date)}` : ''}`);
}

/**
 * The default timings that apply to every day, ignoring any date-specific override.
 * (Mock: a past date can never have an override, so it returns the defaults.
 * A real backend should expose a dedicated endpoint.)
 */
export async function getDefaultTimings(): Promise<Timing[]> {
  return http<Timing[]>('/api/admin/timings/defaults');
}

/** With `date`: override that day only. Without: change the default for every day. */
export async function saveTimingOverride(override: TimingOverride): Promise<Timing[]> {
  return http<Timing[]>('/api/admin/timings', { method: 'PUT', body: override });
}

/** Returns all three meals of that date, updated. */
export async function closeMeal(date: string, mealType: MealType | 'all'): Promise<void> {
  await http('/api/admin/closures', { method: 'POST', body: { date, mealType } });
}

/** Extra: undo a closure. Returns all three meals of that date, updated. */
export async function reopenMeal(date: string, mealType: MealType | 'all'): Promise<void> {
  await http(`/api/admin/closures?date=${encodeURIComponent(date)}&mealType=${encodeURIComponent(mealType)}`, { method: 'DELETE' });
}

/**
 * Closures that have not finished yet, soonest first, looking `days` days ahead
 * (today included). Meals whose service window has already ended are left out.
 */
export async function getUpcomingClosures(days: number = 30): Promise<Closure[]> {
  return http<Closure[]>(`/api/admin/closures?days=${days}`);
}

// ------------------------------------------------------------- student

export async function getStudentProfile(): Promise<{ id: string; name: string }> {
  const result = await http<{ user: { id: string; name: string } }>('/api/auth/me');
  return { id: result.user.id, name: result.user.name };
}
