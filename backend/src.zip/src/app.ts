import express from "express";
import type { ErrorRequestHandler } from "express";
import { authRouter } from "./auth.js";
import { mealsRouter } from "./meals.js";
import { qrRouter } from "./qrRoutes.js";
import { staffRouter } from "./staffRoutes.js";
import { leaveRouter } from "./leaveRoutes.js";
import { studentAccountRouter } from "./studentAccountRoutes.js";
import { adminScheduleRouter } from "./adminScheduleRoutes.js";
import { adminMembershipRouter } from "./adminMembershipRoutes.js";
import { prisma } from "./db.js";

export const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "64kb" }));
app.get("/api/health", (_req, res) => res.json({ status: "ok", serverNow: new Date().toISOString() }));
app.get("/api/ready", async (_req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ status: "ready" });
  } catch {
    res.status(503).json({ code: "DATABASE_UNAVAILABLE", message: "Database is not ready" });
  }
});
app.use("/api/auth", authRouter);
app.use("/api/meals", mealsRouter);
app.use("/api/qr", qrRouter);
app.use("/api/staff", staffRouter);
app.use("/api/leaves", leaveRouter);
app.use("/api/student", studentAccountRouter);
app.use("/api/admin", adminScheduleRouter);
app.use("/api/admin", adminMembershipRouter);
app.use((_req, res) => res.status(404).json({ code: "NOT_FOUND", message: "Route not found" }));
const errorHandler: ErrorRequestHandler = (error: unknown, _req, res, next) => {
  if (res.headersSent) return next(error);
  if (error instanceof SyntaxError && "body" in error) {
    res.status(400).json({ code: "BAD_REQUEST", message: "Invalid JSON body" });
    return;
  }
  console.error("Request failed:", error instanceof Error ? error.name : "UnknownError");
  res.status(500).json({ code: "INTERNAL_ERROR", message: "Request failed" });
};
app.use(errorHandler);
